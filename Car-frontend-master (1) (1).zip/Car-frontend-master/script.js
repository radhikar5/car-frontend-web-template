$(document).ready(function(){
  $(".btn").click(function(){
      $("nav ul").slideToggle(3000);
  })  
})